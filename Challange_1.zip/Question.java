import java.util.Scanner;

class Question
{
	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		int size =sc.nextInt();
		int count=0;
		int[] arr= new int[size];
		if(size>=1&&size<=Math.pow(10,5))
		{
		for(int i=0;i<size;i++)
		{
			arr[i]=sc.nextInt();
		}
		
		for(int j=size-1;j>=0;j--)
		{
			if(j!=0)
			{
				if(arr[j-1]>arr[j])
				{
					count++;
					arr[j-1]=arr[j];
				}
			}
		}
		for(int i=0;i<size;i++)
		{
			if(i!=0)
			{
				if(arr[i-1]>arr[i])
				{
					count++;
					
				}
			}
			
		}
		System.out.println(count);
		}
		
	}
}