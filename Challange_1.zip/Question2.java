import java.util.Scanner;

class Question2
{

	public static void main(String...agrs)
	{
		Scanner sc= new Scanner(System.in);
		StringBuffer line =new StringBuffer(sc.next());
		int row =sc.nextInt();
		int num=line.length()/row;
		int num1=num;
		int num2=num;
		int incr =0;
		while(num>0)
		{
			for(int i=0+incr;i<line.length();i=i+num1)
			{
				if(line.charAt(i)!=' ')
				{
				System.out.print(line.charAt(i));
				line.setCharAt(i,' ');
				}
				
			}
			num2=num2/2;
			num1=num1-num2;
			incr++;
			num--;
		}
		
		
		
		
		
		
		
		
		
	}
}