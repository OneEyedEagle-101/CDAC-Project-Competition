import java.util.Scanner;

class Question3
{
	int lastWordCount(String s)
	{
		int count=0;
		int wordCount=0;
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)==' ')
			{
				wordCount++;
			}
		}
		if(wordCount>0)
		{
			for(int j=s.length()-1;j>=0;j--)
				{
					if(s.charAt(j)==' ')
					{
						for(int m=j+1;m<s.length();m++)
						{
							count++;
						}
						break;
					}
				}
				return count;
		}
		else 
			return 0;
	}
	public static void main(String[] args)
	{
		Scanner sc =new Scanner(System.in);
		String line =sc.nextLine();
		Question3 q3=new Question3();
		
		System.out.println(q3.lastWordCount(line));
	}
}